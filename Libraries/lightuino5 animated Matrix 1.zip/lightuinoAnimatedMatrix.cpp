#include "ideCompat.h"
#include "lightuino.h"
#include "lightuinoAnimatedMatrix.h"
#include "inttypes.h"
#include <lightuinoTimer2.h>

lightuinoAnimatedMatrix* ledMatrix= 0;

lightuinoAnimatedMatrix::lightuinoAnimatedMatrix(LightuinoSink& lht, LightuinoSourceDriver& srcDrvr,unsigned char pstartRow,unsigned char pnumRows):sink(lht),src(srcDrvr)
{

  duration      = 0.25; // Duration time of a transition
  totTransition = 0;    // Length of the transition cycle
  totPWM        = 0;    // Length of PWM cycle
 
  resetAnimationCounters();
 
  startRow = pstartRow;
  numRows = pnumRows;
  memset(&videoRam1,0,NUMOUTSDIV8ADD1*Lightuino_NUMSRCDRVR);
  memset(&videoRam2,0,NUMOUTSDIV8ADD1*Lightuino_NUMSRCDRVR);
  videoRamCurrent = videoRam1;    // Current image buffer
  videoRamNext    = videoRam2;    // Next image buffer
  videoRamUsed    = videoRam1;    // Current image buffer that is being used
  curRow = numRows+startRow;
  sink.finishReq=false; 
  ledMatrix=0;
  
  // Start with normal loop
  LightuinoTimer2::set(doLoop);
  stopAutoLoop();
  
}
// Reset counters
void inline lightuinoAnimatedMatrix::resetAnimationCounters()
{
  noPWM         = 0; // Position in PWM cycle  
  noTransition  = 0; // Position in transition cycle
  curTransition = 0; // Position in transition cycle, fixed during single PWM run
  noImg1        = 0; // Image 1 counter 	
}

// Destructor
lightuinoAnimatedMatrix::~lightuinoAnimatedMatrix()
{
	stopAutoLoop();
}

// Updates shown image with updated image
void lightuinoAnimatedMatrix::update()
{  	
	// Swap next buffer with current buffer
	unsigned char * videoRamTemp(videoRamCurrent);
    videoRamCurrent = videoRamNext;
    videoRamNext    = videoRamTemp;
	videoRamUsed    = videoRamNext;
} 

// Animates from shown image to updated image
void lightuinoAnimatedMatrix::animate()
{ 		
	// Increase refresh-rate
	float rate = numRows*500.0f;
	
	// Reset animation counters
    resetAnimationCounters();
	
	
	// Update transition times
	totTransition = duration * rate;                // no of counts for full transition
	//totPWM = max((int)((float)rate / 200.0f),5);  // no of counts for a single PWM loop
	totPWM = max((int)((float)rate / 100.0f),10);   // no of counts for a single PWM loop
			
	startAutoLoop(rate);	
		
	// Start running animated loop
	LightuinoTimer2::set(doAnimatedLoop);
} 

void lightuinoAnimatedMatrix::pixel(unsigned char x,unsigned char y,unsigned char val)
{
  // Write pixels to next image buffer
  int offset = (y*NUMOUTSDIV8ADD1) + (x>>3);
  
  if (val)
	videoRamNext[offset] |= (1 << (x&7));
  else
	videoRamNext[offset] &= ~(1 << (x&7));
}

// Normal loop
void lightuinoAnimatedMatrix::loop()
{   
	curRow++;
	if (curRow >= startRow+numRows) 
	  {
		curRow=startRow;
	  }
	sink.set(0,0,0);  		
	if (curRow ==startRow) 
		src.shift(1); // Turn on 1st source        
	else 
		src.shift(0); // Go to next source
	sink.set(videoRamCurrent + (curRow*NUMOUTSDIV8ADD1));               
}

// Loop that animates from current frame to next frame
void lightuinoAnimatedMatrix::animatedLoop()
{   
	cli(); // Disable interrupts
	curRow++;
	if (curRow >= startRow+numRows) 
	  {
		curRow=startRow;
	  }
	sink.set(0,0,0);  	// Turn off sinks	
	if (curRow ==startRow) 
	{ 		
		src.shift(1);  // Turn on 1st source		
		videoRamUsed = frameToShow() ?  videoRamNext: videoRamCurrent;
	}		
	else 
		src.shift(0);	// Go to next source
	sink.set(videoRamUsed + (curRow*NUMOUTSDIV8ADD1));  // Set new sinks     
    
	sei(); // Re-enable interrupts
	
	if (curTransition >= totTransition) { returnToNormalLoop(); }
	
}

// Determines if frame 0 or 1 should be shown 
bool inline lightuinoAnimatedMatrix::frameToShow()
{		
	// next PWM cycle 
	noTransition++;
	noPWM++;
	
	//if at start of a PWM cycle
    if (noPWM >= totPWM) {	
		curTransition = noTransition;  // used for  blend ratio during PWM
		noPWM = 0;					   // reset PWM counter
		noImg1 = 0;					   // reset image 1 counter
	} 	
	//Determine if next image to show is image 0 or image 1: 
    // Show image 1 if noImg1 percentage is smaller than blend img1-to-img0 ratio	
	// rewrite so we don't need to use fractions (floating point values)    
	// noImg1/noPWM < blendRatio = curTransition/totTransition  -->
	// noImg1 * totTransition <  noPWM * curTransition 
	
	if((noImg1 * totTransition) < (noPWM * curTransition )) {
		// show next frame 
		noImg1++;
		return 1;		    
	}
	// show current frame
	return 0;	
}

// Go from animated to still loop
void inline lightuinoAnimatedMatrix::returnToNormalLoop()
{
	// Swap next buffer with current buffer
	
	unsigned char * videoRamTemp(videoRamCurrent);
    videoRamCurrent = videoRamNext;
    videoRamNext    = videoRamTemp;
	videoRamUsed    = videoRamNext;
	
	// Run with normal loop
	LightuinoTimer2::set(doLoop);
	
	// Decrease to default refresh-rate
	startAutoLoop(numRows*100.0f);
}


// Static function calling loop once.
void lightuinoAnimatedMatrix::doLoop()
{
	if (ledMatrix) {ledMatrix->loop();}
}

// Static function calling animatedloop once.
void lightuinoAnimatedMatrix::doAnimatedLoop()
{
	if (ledMatrix) {ledMatrix->animatedLoop();}
}

// Start automatic refreshing with custom scanrate
void lightuinoAnimatedMatrix::startAutoLoop(float rate)
{	
	ledMatrix = this;	
	LightuinoTimer2::start(rate);	
}

// Start automatic refreshing of scanlines
void lightuinoAnimatedMatrix::startAutoLoop()
{	
	startAutoLoop(numRows*100.0f);	
}

// Stop automatic refreshing of scanlines
void lightuinoAnimatedMatrix::stopAutoLoop()
{
	 if (ledMatrix == this) {
		LightuinoTimer2::stop;
		ledMatrix = 0;
	}  
}



